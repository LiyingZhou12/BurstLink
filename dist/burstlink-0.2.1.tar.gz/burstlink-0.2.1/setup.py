from setuptools import setup

setup(
    name="burstlink",
    version="0.2.1", 
)